#include<iostream>
using namespace std;
int main ()
{
int Stack[100], Top=0, MaxSize=100;//Stack[] holds the elements; Top is the index of Stack[] always holding the whereabouts of the first/top element of the stack
bool isEmpty(); //returns True if stack has no element
bool isFull(); //returns True if stack full
bool push(int Element); //inserts Element at the top of the stack
bool pop(); //deletes top element from stack into Element
int topElement(); //gives the top element in Element
void show(); //prints the whole stack
return 0;
}
