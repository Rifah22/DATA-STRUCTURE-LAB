#include<iostream>
using namespace std;
int main(){
int n,arr[n];
int size=sizeof(arr)/sizeof(int);
cout<<"Enter  array size:";
cin>>n;
cout<<"\nEnter elements of array:";
for(int i=0;i<n;i++)
    {
        cin>>arr[i];
    }
for(int i=0;i<n;i++)
    {
for(int j=i+1;j<n;j++)
    {
    if(arr[i]==arr[j])
    {
for(int i=j;i<n;i++)
    {
    arr[i] = arr[i+1];
    }
}
}
}
cout<<"Duplicate element in the changed array: ";
for(int i=0;i<n;i++)
{
 cout<<arr[i];
}
for(int i=0;i<n;i++)
    {
    if(arr[i]==n)
    {
    cout<<"\n Array already unique!"<<endl;
    }
}
return 0;
}




