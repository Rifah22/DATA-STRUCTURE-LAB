#include<iostream>
using namespace std;
int main ()
{

//Object Oriented Approach//

 class MyStack{
int Stack[100], Top, MaxSize;
public:
//Initializing stack
MyStack( int Size = 100 ){	MaxSize = Size; Top = 0;}
bool isEmpty();
bool isFull();
bool push(int Element);
bool pop();
int topElement();
void show();
};

//Dynamic Stack//

class MyStack{
int *Stack, Top, MaxSize;
public:
MyStack(int);
~MyStack();
bool isEmpty();
bool isFull();
bool push(int Element);
bool pop();
bool topElement();
void show();
void resize( int size); //Resize the stack
};

//Dynamic Stack: Constructor & Destructor//

MyStack::MyStack( int Size = 100 ){
	MaxSize = Size; //get Size
	Stack = new int[MaxSize]; //create array accordingly
	Top = 0; //start the stack
}

MyStack::~MyStack(){
	delete [] Stack; //release the memory for stack
}

//Dynamic Stack: Runtime Resizing//

void resize( int Size = 100 ){
	//creates a new stack with a new capacity, MaxSize + Size
	int *tempStk = new int[ MaxSize + Size ];
	//copy the elements from old to new stack
	for( int i=0; i<MaxSize; i++ ) tempStk[i] = Stack[i];
	MaxSize += Size; //MaxSize increases by Size
	delete [] Stack; //release the old stack
	Stack = tempStk; //assign Stack with new stack
}
void push( int Element ){
	//inserts Element at the top of the stack
	if( isFull( ) )	resize( ); //increase size if full
 	Stack[ Top++ ] = Element;
}

//Generic Stack//

template <typename T>
class MyStack{
T *Stack;
int Top, MaxSize;
public:
MyStack( int );
~MyStack();
bool isEmpty();
bool isFull();
bool push(T);
bool pop();
bool topElement();
void show();
void resize(int); //resize the stack
};

}





