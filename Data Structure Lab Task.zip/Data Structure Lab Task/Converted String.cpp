#include<iostream>
using namespace std;
void encode(string s, int j)
{
for(int i=0; i<s.length(); i++)
{
  int conv;
  conv = s[i]+j;
  s[i]=(char)(conv+2);
 }
cout<<"converted string : "<<s<<endl;
}
int main()
{
 string s;
 int j;
 cout<<"Enter a string: "<<endl;
 cin>>s;
 getline (cin,s);
 cout<<"Enter a  integer:"<<endl;
 cin>>j;
 cout<<"Sample string(s) : "<<s<<endl;
 cout<<"Sample string(j) : "<<j<<endl;
 encode (s,j);
 return 0;
}

