#include <iostream>
using namespace std;
int main()
{
int i,j,k,row,col;
int a1[20][20];
int a2[20][20];
int mul[50][50];
cout<<"Enter the number of row:";
cin>>row;
cout<<"Enter the number of column:";
cin>>col;
cout<<"Enter the first matrix element:"<<endl;
for(i=0;i<row;i++)
{
 for(j=0;j<col;j++)
 {
  cin>>a1[i][j];
 }
}
cout<<"Enter the second matrix element:"<<endl;
for(i=0;i<row;i++)
{
 for(j=0;j<col;j++)
 {
  cin>>a2[i][j];
 }
}
cout<<"Multiply of the matrix:"<<endl;
for(i=0;i<row;i++)
{
 for(j=0;j<col;j++)
 {
  mul[i][j]=0;
  for(k=0;k<row;k++)
  {
   for(k=0;k<col;k++)
   {
    mul[i][j]=mul[i][j]+a1[i][k]*a2[k][j];
   }
  }
 }
}
for(i=0;i<row;i++)
{
 for(j=0;j<col;j++)
 {
  cout<<mul[i][j]<<" ";
 }
 cout<<endl;
}
return 0;
}
