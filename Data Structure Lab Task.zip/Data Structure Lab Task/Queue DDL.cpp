#include<iostream>
using namespace std;
struct Node
{
    int data;
    Node*next ;
};
class Queue
{
 Node *front,*rear;
public:
    Queue()
    {
    front=rear=NULL;
    }
    void enqueue(int e)
    {
        Node*newnode;
        newnode=new Node();
        newnode->data=e;
        newnode->next=NULL;
        if(front==NULL)
        {
        front=rear=newnode;
        }
        else
        {
        rear->next=newnode;
        rear=newnode;
        }
    }
    void dequeue()
    {
    Node*x;
        if(front==NULL)
        {
        cout<<"Queue is Empty";
        }
        else
        {
        x= front;
        front = front->next;
        delete x;
        }
    }
    void print()
    {
    Node*x;
    x=front;
    while(x!=NULL)
    {
    cout<<x->data<<"\n";
    x=x->next;
    }
    cout<<endl;
    }
};
int main()
{
    Queue q;
    q.enqueue(1);
    cout<<"First enqueue :"<<endl;
    q.print();
    q.enqueue(2);
    cout<<"Second enqueue :"<<endl;
    q.print();
    q.dequeue();
    cout<<"First dequeue :"<<endl;
    q.print();
    q.dequeue();
    q.enqueue(3);
    cout<<"Third enqueue :"<<endl;
    q.print();
    q.enqueue(4);
    cout<<"Fourth enqueue :"<<endl;
    q.print();
    q.dequeue();
    cout<<"Second dequeue :"<<endl;
    q.print();
}
