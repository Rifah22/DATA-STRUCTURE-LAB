#include<iostream>
using namespace std;
int main ()
{
int Queue[4],MaxSize=4,Initialize;
//Check IsEmpty
//Check IsFull
//EnQueue (add element to back i.e. at the rear)
//DeQueue (remove element from the front)
//FrontValue (retrieve value of element from front)
//ShowQueue (print all the values of queue from front to rear)

Initialize ()front=rear=-1

EnQueue( 3 ) front=rear=0
EnQueue( 6 ) rear = 1
EnQueue( 2 ) rear = 2
EnQueue( 5 ) rear = 3

EnQueue( 9 ) Queue Full, if (rear==(MaxSize-1))

DeQueue() front = 1
DeQueue() front = 2
DeQueue() front = 3

DeQueue()  front=rear=-1, if ((front!=-1) && (front==rear))

DeQueue()  Queue Empty, if ((front==-1) && (rear==-1))

return 0;
}
