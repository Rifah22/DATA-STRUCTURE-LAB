#include<iostream>
using namespace std;
void swapping(int &a,int &b)
{
    int k=a;
    a=b;
    b=k;
}
void bubbleSort(int soa,int arr[])
{
    for(int i=0;i<soa;i++)
    {
        for(int j=0;j<soa-1-i;j++)
        {
            if(arr[j]>arr[j+1])
            {
               swapping(arr[j],arr[j+1]) ;
            }
        }
    }
}
void show(int soa,int arr[])
{
    for (int i=0;i<soa;i++)
    {

        cout<<arr[i]<<" ";
    }
}
int main()
{
    int soa;
    cout<<"Enter the size of Array: ";
    cin>>soa;
    int arr[soa];
    cout<<"Enter the elements of Array: ";
    for(int i=0;i<soa;i++)
    {
        cout<<"Index ["<<i<<"] :";
        cin>>arr[i];
    }
    bubbleSort(soa,arr);
    show(soa,arr);
    return 0;
}
