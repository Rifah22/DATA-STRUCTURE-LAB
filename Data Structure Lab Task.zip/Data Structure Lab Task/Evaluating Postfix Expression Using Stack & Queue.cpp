Postfix Expression: 26*41-/53*+
EnQueue( ')' );
while ( FrontElement() != ')' ) do{
    OP = FrontElement();
    DeQueue();
    if OP is OPERAND then Push( OP );
    else if OP is OPERATOR then{
	OperandRight = TopElement();
	Pop();
	OperandLeft = TopElement();
	Pop();
	x = Evaluate(OperandLeft, OP, OperandRight);
	Push(x);
    }
}
Result = TopElement();
Pop();
cout << Result;
