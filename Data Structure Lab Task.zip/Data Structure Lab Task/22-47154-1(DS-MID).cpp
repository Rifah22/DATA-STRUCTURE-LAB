#include<iostream>
using namespace std;
void insertionsort(int marks[],int cnum)
{
for(int i=1;i<cnum;i++)
    {
        int k=marks[i];
        int j=i-1;
            while(j>=0 && marks[j]>k)
            {
                marks[j+1]=marks[j];
                j=j-1;
            }
            marks[j+1]=k;
            cout<<marks[j];
    }
}
    void show(int marks[],int cnum)
    {
    for(int i=0;i<cnum;i++)
    {
        cout<<marks[i]<<" ";
    }
    }



int main()
{
    int cnum;
    int marks[cnum];
    int credit[cnum];
    cout<<"Enter total number of course: ";
    cin>>cnum;
    for(int i=0;i<cnum;i++)
    {
        cout<<"Please input  "<<i+1<< " course marks: ";
        cin>>marks[i];
    }
    /* for(int i=0;i<cnum;i++)
    {
        cout<<"Course credit "<<i+1<<" number: ";
        cin>>credit[i];
    }*/
    for(int i=0;i<cnum;i++)
    {
        cout<<"Marks "<<marks[i]<<" ";
        cout<<endl;
    }
    insertionsort(marks,cnum);
    show(marks,cnum);
    for(int i=0;i<cnum;i++)
    {
        char grade;
        float cg;
        if(marks[i]>=90 && marks[i]<=100)
        {
           grade='A+';
           cg=4.00;
        }
        if(marks[i]>=85 && marks[i]<90)
        {
           grade='A';
           cg=3.75;
        }
        if(marks[i]>=80 && marks[i]<85)
        {
           grade='B+';
           cg=3.50;
        }
        if(marks[i]>=75 && marks[i]<80)
        {
           grade='B';
           cg=3.25;
        }
        if(marks[i]>=70 && marks[i]<75)
        {
           grade='C+';
           cg=3.00;
        }
        if(marks[i]>=65 && marks[i]<70)
        {
           grade='C';
           cg=2.75;
        }
        if(marks[i]>=60 && marks[i]<65)
        {
           grade='D+';
           cg=2.50;
        }
        if(marks[i]>=50 && marks[i]<600)
        {
           grade='D';
           cg=2.25;
        }
        if(marks[i]>=0 && marks[i]<50)
        {
           grade='F';
           cg=0.00;
        }
        if(marks[i]==-1)
        {
           grade='I';
           cg=0.00;
        }
        if(marks[i]==-2)
        {
           grade='W';
           cg=0.00;
        }
        if(marks[i]==-3)
        {
           grade='UW';
           cg=0.00;
        }
        cout<<"course: "<<i+1<<" grade: "<<grade<<" and cgpa: "<<cg;
        cout<<endl;
    }
    return 0;
}


