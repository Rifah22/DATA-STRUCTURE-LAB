dequeue(){
  if(queue empty): {error: �queue is empty! dequeue not possible�}
  otherwise if (front and rear are equal): {front=rear=-1;}
  otherwise: {front++;}
}

frontElement(){
  return queue[front];
}

showQueue(){
  if (queue empty)
    error: �cannot show queue because it is empty�;
  otherwise:
    for: i=front; i<=rear; i++
      output: queue[front];
}
