#include<iostream>
using namespace std;
struct faculty
{
    int id;
    float salary;
    int joining_year;
};
int main()
{
   int n;
   faculty f[100];
   cout<<"Enter the number of Faculty....\n";
   cin>>n;
   cout<<"Enter the necessary information...\n";
   for(int i=0;i<n;i++)
   {
    cout<<"Id of Faculty ["<<i+1<<"]=";
    cin>>f[i].id;
     for(int j=0;j<i;j++)
        {
          if(f[i].id==f[j].id)
            {
            cout<<"Try again ";
            cout<<"Id of Faculty ["<<i+1<<"]=";
            cin>>f[i].id;
            }
        }
         cout<<"Salary :";
         cin>>f[i].salary;
         cout<<"JoiningYear :";
         cin>>f[i].joining_year;
    }
    for(int i=0;i<n;i++)
    {
      cout<<"More then 5 years....... "<<endl;
        if(f[i].joining_year<2017)
        {
            cout<<"ID : "<<f[i].id<<endl;
            cout<<"Salary : "<<f[i].salary<<endl;
            cout<<"JoiningYear : "<<f[i].joining_year<<endl;
        }
    }
    for(int i=0;i<n;i++)
    {
      cout<<" Salary More then 100000....... "<<endl;
        if(f[i].salary>100000)
        {
            cout<<"ID : "<<f[i].id<<endl;
            cout<<"Salary : "<<f[i].salary<<endl;
            cout<<"JoiningYear : "<<f[i].joining_year<<endl;
        }
    }
return 0;
}
