Infix Expression: 2*6/(4-1)+5*3
Add ')' to the end of Infix;    Push( '(' );
do{
  OP = next symbol from left of Infix;
  if OP is OPERAND then EnQueue( OP );
  else if OP is OPERATOR then{
    if OP = '(' then Push( OP );
    else if OP = ')'  then{
        while TopElement() != '(' do{
	Enqueue(TopElement());
	Pop();
        }
	Pop();
    }else{
    while Precedence( OP ) <= Precedence( TopElement() ) do{
	Enqueue(TopElement());
	Pop();
    }
    Push( OP );
    }
}while !IsEmpty();
