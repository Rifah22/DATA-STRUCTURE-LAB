
Initialize queue[maxSize]; front = rear = -1;

isEmpty(){
 if ((front==-1) and (rear==-1)):
   then return true;
}

isFull(){
 if rear==(maxSize-1):
   then return true;
}

enqueue(x){
  if(queue full): {error: "queue full!";}
  otherwise if(queue is empty): {front=rear=0; insert x in queue[rear]}
  otherwise: rear++; insert x in queue[rear];
}

