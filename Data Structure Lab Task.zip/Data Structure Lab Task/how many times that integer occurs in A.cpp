#include<iostream>
using namespace std;



int fre(int a[], int n, int x)
{
    int count = 0;
    for (int i=0; i < n; i++)
       if (a[i] == x)
          count++;
    return count;
}




int main() {
    int a[] = {8,4,6,1,6,9,6,1,9,8};
    int x = 6;
    int n = sizeof(a)/sizeof(a[0]);
    cout << fre(a, n, x);
    return 0;
}
