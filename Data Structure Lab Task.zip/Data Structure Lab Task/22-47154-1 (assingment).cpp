#include <iostream>
using namespace std;
struct CovidVaccineperson
{
    int nid,age,registerationnumber;
    string name,phonenumber ,vaccinename,centername,dose1,dose2,boosterdose;
};
string code(string s )
{
    for(int i=0;i<s.size();i++)
    {
    if(s[4]<=1 && s[5]<=2)
    {
    for(int i=6;i<7;i++)

        {
        s[i]+=2;
        }
    }
    if(s[4]>=1 && s[5]>2)
    {
        for(int i=8;i<9;i++)

        {
        s[i]+=1;
        }
    }
    }


    return s;
}

int main()
{
    int n;
    cout<<"Enter the number of person: ";
    cin>>n;
    CovidVaccineperson p[n];
    cout<<"Enter the information....\n";
    for(int i=0;i<n;i++)
    {
        cout<<"Person ["<<i+1<<"]\n";
        cout<<"Name: ";
        cin>>p[i].name;
        cout<<"NID Number: ";
        cin>>p[i].nid;
        cout<<"Age: ";
        cin>>p[i].age;
        cout<<"Phone Number: ";
        cin>>p[i].phonenumber;
        cout<<"Registeration Number: ";
        cin>>p[i].registerationnumber;
        cout<<"Name of Vaccine: ";
        cin>>p[i].vaccinename;
        cout<<"Center Name: ";
        cin>>p[i].centername;
        cout<<"Date of 1st Dose: ";
        cin>>p[i].dose1;
        cout<<"Date of 2nd Dose: ";
        cin>>p[i].dose2;
        cout<<"Date of booster Dose: ";
        cin>>p[i].boosterdose;
    }

    for(int i=0;i<n;i++)
    {
        string cs=code(p[i].dose1);
        if(p[i].centername=="DMC")
        {
            cout<<"Center is Dhaka Medical College"<<endl;
            cout<<"Person ["<<i+1<<"]\n";
            cout<<"Name: "<<p[i].name<<endl;
            cout<<"NID Number: "<<p[i].nid<<endl;
            cout<<"Age: "<<p[i].age<<endl;
            cout<<"Phone Number: "<<p[i].phonenumber<<endl;
            cout<<"Registeration Number: "<<p[i].registerationnumber;
            cout<<"Center Name: "<<p[i].centername<<endl;
            cout<<"Name of Vaccine: "<<p[i].vaccinename<<endl;
            cout<<"Date of 1st Dose: "<<p[i].dose1<<endl;
            cout<<"Date of 2nd Dose: "<<p[i].dose2<<endl;
            cout<<"Date of booster Dose: "<<p[i].boosterdose<<endl;
        }
        else
        {
            cout<<"Person ["<<i+1<<"]\n";
            cout<<"Name: "<<p[i].name<<endl;
            cout<<"NID Number: "<<p[i].nid<<endl;
            cout<<"Age: "<<p[i].age<<endl;
            cout<<"Phone Number: "<<p[i].phonenumber<<endl;
            cout<<"Registeration Number: "<<p[i].registerationnumber;
            cout<<"Center Name: "<<p[i].centername<<endl;
            cout<<"Name of Vaccine: "<<p[i].vaccinename<<endl;
            cout<<"Date of 1st Dose: "<<p[i].dose1<<endl;
            cout<<"Date of 2nd Dose: "<<p[i].dose2<<endl;
            cout<<"Date of booster Dose: "<<p[i].boosterdose<<endl;
        }

    }

   return 0;
}
