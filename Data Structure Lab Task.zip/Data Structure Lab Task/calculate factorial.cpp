#include <iostream>
using namespace std;

void factorial(int num)
{
    int count=0;
    double fact=1;
    for(int j=1;j<=num;j++)
    {
        if((num%j) == 0)
        {
            count++;
        }
    }
    if(count == 2)
    {
        for(int i=num;i>0;i--)
        {
            fact=fact*i;
        }
        cout<<"Output:"<<fact<<endl;
    }
    else
    {
         cout <<"Error! "<<num<< " is not a Prime Number"<<endl;
    }
}


