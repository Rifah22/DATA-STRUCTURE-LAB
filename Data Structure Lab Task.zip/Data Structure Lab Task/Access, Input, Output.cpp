#include<iostream>
using namespace std;

// null-terminated sequences of characters
int main ()
{


char Question[]="Please, enter first name: ";
char Greeting[] = "Hello";
char FirstName[80];
cout<<Question;
cin>>FirstName;
cout<<Greeting<<", "<<FirstName;

return 0;
}
