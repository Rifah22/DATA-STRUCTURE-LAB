#include<iostream>
using namespace std;
void insertionSort(int arr[],int soa)
{

    int k;
    for(int i=1;i<soa;i++)
    {
        k=arr[i];
        int j=i-1;
            while(j>=0 && arr[j]>k)
            {
                arr[j+1]=arr[j];
                j=j-1;
            }
            arr[j+1]=k;
            cout<<arr[j];
    }
}
void show(int arr[],int soa)
{
    for(int i=0;i<soa;i++)
    {
        cout<<arr[i]<<" ";
    }
}
int main()
{
   /* int arr[]={12,11,13,1,2};
    int soa=sizeof(arr)/sizeof(int);
    */
    int soa;
    cout<<"Enter the size of Array: ";
    cin>>soa;
    int arr[soa];
    cout<<"Enter the elements of Array: ";
    for(int i=0;i<soa;i++)
    {
        cout<<"Index ["<<i<<"] :";
        cin>>arr[i];
    }
    insertionSort(arr,soa);
    show(arr,soa);
    return 0;
}
