#include<iostream>
using namespace std;
int main()
{
int row,col;
cout<<"Enter the numbers of row: ";
cin>>row;
cout<<"Enter the numbers of column: ";
cin>>col;
int arr[row][col];
for(int i=0; i<row; i++)
{
 for(int j=0; j<col; j++)
  {
    cout<<"arr["<<i<<"]["<<j<<"]:";
    cin>>arr[i][j];
  }
}
cout<<"Your entered array is: \n";
for(int i=0; i<row; i++)
{
 for(int j=0; j<col; j++)
  {
    cout<<arr[i][j]<<"  ";
  }
  cout<<endl;
}
int arr1[col][row];
for(int j=0; j<col; j++)
{
 for(int i=0; i<row; i++)
  {
    cout<<"arr1["<<j<<"]["<<i<<"]:";
    cin>>arr1[j][i];
  }
}
cout<<"Your entered array is: \n";
for(int j=0; j<col; j++)
{
 for(int i=0; i<row; i++)
  {
    cout<<arr1[j][i]<<"  ";
  }
  cout<<endl;
}
cout<<"Your entered array's transpose is: \n";
for(int j=0; j<col; j++)
{
 for(int i=0; i<row; i++)
  {
    cout<<arr1[i][j]<<"  ";
  }
  cout<<endl;
}
return 0;
}

