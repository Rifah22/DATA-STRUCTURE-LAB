#include<iostream>
using namespace std;
int main()
{
    int array1[]={8,4,6,1,6,9,6,1,9,8};
    int count=1;
    int s1;
    int a,b;
    int occ[10];
    int size=sizeof (array1)/sizeof(int);
    for(int a=0;a<s1;a++)
    {
       if(array1[a]==array1[b])
        {
            occ[b]=0;
            count++;

        }
        else if (occ[a]!=0){
            occ[a]=count;
        }
    }
 cout<<"Enter the number of time each element occurs in the array:";
    for(a=0; a<s1; a++)
    {
        if(occ[a]!=0)
        {

            cout<<array1[a]<<" occurs = "<<occ[a];
        }
    }
    return 0;
}

