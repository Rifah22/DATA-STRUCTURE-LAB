#include <iostream>
using namespace std;
int main()
{
int x,y;
int arr1[x],arr2[y];
cout<<"Enter the number of the first array: ";
cin>>x;
cout<<"Enter the elements of the first array:\n";
for(int i=0;i<x;i++)
{
    cin>>arr1[i];
}
cout<<"Enter the number of  the second array: ";
cin>>y;
cout<<"Enter the elements of the second array:\n";
for(int i=0;i<y;i++)
{
    cin>>arr2[i];
}
cout<<"First array elements are: ";
for(int i=0;i<x;i++)
{
    cout<<arr1[i];
}

cout<<"Second array elements are: ";
for(int i=0;i<y;i++)
{
    cout<<arr2[i];
}
int z=0;
int arr3[z];
for(int i=0;i<x;i++)
{
for(int j=0;j<y;j++)
{
if(arr1[i]==arr2[j])
{
 z++;
 arr3[z-1]=arr1[i];
}
}
}
if(z==0)
{
    cout<<"No common element!\n";
}
else
{
cout<<" The array of common elements are: ";
for(int i=0;i<z;i++)
{
cout<<arr3[i]<<" ";
}
}
return 0;
}
